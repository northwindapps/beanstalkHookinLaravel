#!/bin/bash
chmod -R 775 /var/www/html/storage

php /var/www/html/artisan config:cache